# Temp Mail Maker Bot

Telegram bot jo temporary email banata hai (mail.tm API) aur inbox yahin dikhata hai.
Force-join: https://t.me/geniushackertools

**Developer: Aditya**

## Setup
1. @BotFather se bot banao, token lo.
2. Bot ko channel `@geniushackertools` me **Admin** banao (warna join check kaam nahi karega).
3. Is repo ko GitHub par upload karo.

## Render Deploy
1. Render -> New -> Web Service -> GitHub repo select karo.
2. Build Command: `pip install -r requirements.txt`
3. Start Command: `python bot.py`
4. Environment Variable add karo: `BOT_TOKEN` = aapka token
5. Deploy. (Free plan par sleep na ho isliye UptimeRobot se Render URL ko 5 min me ping karwao.)

## Local run
```
pip install -r requirements.txt
export BOT_TOKEN=xxxx
python bot.py
```
